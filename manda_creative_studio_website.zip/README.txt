MANDA CREATIVE STUDIO — WEBSITE STARTER

Included:
- index.html: responsive one-page website with Home, Services, Portfolio, About and Contact sections.
- Black-and-gold luxury styling, designed for mobile and desktop.

Before publishing:
1. Open index.html in a browser to preview it.
2. In the script near the bottom, replace YOUR_EMAIL_HERE with your real business email.
3. Replace the sample portfolio tiles with your own project images and captions.
4. Add your real social media links and business details if desired.
5. Upload index.html to a hosting provider or give the file to your web developer.

Note: This is a ready-to-customize website starter, not a published live website. The contact form opens an email draft after you add your email address; it does not store submissions.
