MANDA CREATIVE STUDIO — WEBSITE STARTER

Updated contact details:
- WhatsApp bookings: +234 805 310 1392
- Email: tedaluv4u@gmail.com

Booking flow:
- The booking buttons open a WhatsApp chat with MANDA Creative Studio.
- The contact form prepares a WhatsApp message containing the visitor's name, email, requested service and project details.
- The visitor reviews and sends the message in WhatsApp.

Before publishing:
1. Preview index.html in a browser.
2. Replace the sample portfolio tiles with your own project images and captions.
3. Add your real social media links and any other business details.
4. Upload index.html to a hosting provider or give the files to your web developer.

Note: This is a ready-to-customize website starter, not a published live website. The contact form uses the visitor's WhatsApp app and does not store submissions on a server.
